# NyChat implementation roadmap

1. Backend foundation and account tests.
2. OTP/email verification and account recovery.
3. Flutter app shell and responsive web interface using approved brand assets.
4. Direct/group messaging and media storage.
5. Stories and feed, moderation and reporting.
6. WebRTC calls, group meetings and live streaming provider.
7. Wallet ledger, payment-provider sandbox integration, reconciliation and approvals.
8. AI support assistant with permissions and audit logs.
9. Referrals, promotions, virtual gifting and commission rules.
10. Role-specific dashboards, security review, deployment and monitoring.

Do not treat roadmap items as implemented until code, tests, provider setup and security review are completed.
